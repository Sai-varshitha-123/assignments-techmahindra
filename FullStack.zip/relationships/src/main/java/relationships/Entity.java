package relationships;

public @interface Entity {

}
