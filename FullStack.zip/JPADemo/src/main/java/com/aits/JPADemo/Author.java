package com.aits.JPADemo;

public class Author {

}
